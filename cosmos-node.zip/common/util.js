"use strict";
const util = {};
util.throw = (message) => {
    throw new Error(message);
}
module.exports = util;