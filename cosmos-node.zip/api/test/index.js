"use strict";
const test = require('express').Router();

test.get('/api/test', (req, res) => {
    console.log('/api/test');
});

module.exports = test;